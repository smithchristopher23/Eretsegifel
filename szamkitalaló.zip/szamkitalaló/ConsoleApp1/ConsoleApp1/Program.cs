﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ez egy számoló gépes program!");
            int a;
            Console.Write("Első szamot add meg:");
            int szam1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Második számot add meg :");
            int szam2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Milyen művelet legyen (/,+,-,*):");
            string megoldas = Console.ReadLine();



            switch (megoldas)

            {
                case "+":
                    a = szam1 + szam2;
                    Console.WriteLine("összeadás:" + a);

                    break;
                case "-":
                    a = szam1 - szam2;
                    Console.WriteLine("kivonás:" + a);
                    break;
                case "*":
                    a = szam1 * szam2;
                    Console.WriteLine("szorzás:" + a);
                    break;
                case "/":
                    a = szam1 / szam2;
                    Console.WriteLine("osztás:" + a);
                    break;
                
            }
            Console.ReadKey();
        }
    }
}
