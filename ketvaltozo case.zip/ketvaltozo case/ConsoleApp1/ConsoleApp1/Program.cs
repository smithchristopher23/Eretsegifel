﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
            
        {
            Console.WriteLine("Ez a program számokat kér be addig amig 0-ás számot nem kap.");
            int szam;



            do
            {
                Console.WriteLine("Kérem adjon meg egy számot:");
                szam = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("A szám amit beirt:" + szam);
            }
            while (szam != 0);



            if (szam == 0)
            {
                Console.WriteLine("vége a játéknak");
            }



            Console.ReadLine();


        }
    }
}
