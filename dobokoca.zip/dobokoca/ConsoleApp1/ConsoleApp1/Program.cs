﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hányszor legyen feldobás?");
            int dobas = Convert.ToInt32(Console.ReadLine());
            int anniNyert = 0;
            int panniNyert = 0;
            Random random = new Random();
            for (int i = 0; i < dobas; i++)
            {
                int[] kockak = new int[3];
                for (int j = 0; j < 3; j++)
                {
                    kockak[j] = random.Next(1, 7);
                }

                Console.Write($"Dobás: {kockak[0]} + {kockak[1]} + {kockak[2]} = {kockak.Sum()}    ");
                if (kockak.Sum() < 10)
                {
                    Console.WriteLine("Nyert: Anni");
                    anniNyert++;
                }
                else
                {
                    Console.WriteLine("Nyert: Panni");
                    panniNyert++;
                }
            }
            Console.WriteLine($"A játék során {anniNyert} alkalommal Anni, {panniNyert} alkalommal Panni nyert.");
            Console.ReadKey();

        }
    }
}
