﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hány dobás legyen ");
            int darab =Convert.ToInt32(Console.ReadLine());
            Random rnd = new Random();
            int dobas = rnd.Next(0, 6);
            for (int i = 0; i < darab; i++)
            {
                Console.WriteLine(dobas);
            }
        }
    }
}
